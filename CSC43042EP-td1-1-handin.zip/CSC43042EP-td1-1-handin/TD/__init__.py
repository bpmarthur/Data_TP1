"""
TD1: introduction and nearest neighbor search
"""
from TD.kdtree import KDTree  # noqa: F401
from TD.linear_scan import LinearScan  # noqa: F401
